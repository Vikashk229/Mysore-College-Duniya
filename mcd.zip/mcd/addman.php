<html>

<body>
    <input type="text" placeholder="manager id" required>
    <button>add</button>
     </body>







</html>