-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2021 at 05:04 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcd`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `adm` ()  BEGIN
select branch_name,no_of_students_admitted,year from branch b,admission a where b.branch_id=a.branch_id and coll_id=101;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `adm1` ()  BEGIN
select branch_name,no_of_students_admitted,year from branch b,admission a where b.branch_id=a.branch_id and coll_id=103;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `adm2` ()  BEGIN
select branch_name,no_of_students_admitted,year from branch b,admission a where b.branch_id=a.branch_id and coll_id=102;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `plc` ()  BEGIN
select branch_name,no_of_students_placed,year from branch b,placement p where b.branch_id=p.branch_id and coll_id=101;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `plc1` ()  BEGIN
select branch_name,no_of_students_placed,year from branch b,placement p where b.branch_id=p.branch_id and coll_id=102;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `plc2` ()  BEGIN
select branch_name,no_of_students_placed,year from branch b,placement p where b.branch_id=p.branch_id and coll_id=103;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`id`, `user_name`, `password`) VALUES
(1, 'pavanreddy', 'pavan098'),
(2, 'vikas', 'vikas123');

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `coll_id` int(10) NOT NULL,
  `branch_id` int(10) NOT NULL,
  `no_of_students_admitted` int(10) NOT NULL,
  `year` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`coll_id`, `branch_id`, `no_of_students_admitted`, `year`) VALUES
(101, 11, 20, 2019),
(101, 12, 18, 2019),
(101, 13, 21, 2019),
(101, 14, 16, 2019),
(101, 15, 15, 2019),
(101, 16, 17, 2019),
(101, 17, 20, 2019),
(102, 21, 25, 2019),
(102, 22, 19, 2019),
(102, 23, 21, 2019),
(102, 24, 14, 2019),
(102, 25, 19, 2019),
(102, 26, 26, 2019),
(102, 27, 26, 2019),
(102, 28, 19, 2019),
(103, 31, 23, 2019),
(103, 32, 19, 2019),
(103, 33, 22, 2019),
(103, 34, 17, 2019),
(103, 35, 16, 2019);

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(10) NOT NULL,
  `branch_name` varchar(60) NOT NULL,
  `cut_of_start` int(10) NOT NULL,
  `cut_of_end` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`, `cut_of_start`, `cut_of_end`) VALUES
(11, 'Computer Science & Engineering', 200, 5000),
(12, 'Information Science & Engineering', 1000, 6500),
(13, 'Civil Engineering', 2500, 10000),
(14, 'Mechanical Engineering', 2000, 10000),
(15, 'Electrical & Electronics Engineering', 500, 6000),
(16, 'Electronics & Communication Engineering', 800, 8000),
(17, 'Industrial & Production Engineering', 1000, 15000),
(21, 'Computer Science & Engineering', 100, 2000),
(22, 'Information Science & Engineering', 300, 8000),
(23, 'Civil Engineering', 800, 12000),
(24, 'Mechanical Engineering', 500, 7500),
(25, 'Electrical & Electronics Engineering', 400, 8000),
(26, 'Electronics & Communication Engineering', 500, 8000),
(27, 'Industrial & Production Engineering', 1000, 10000),
(28, 'Environmental Engineering', 1000, 10000),
(31, 'Computer Science & Engineering', 3500, 10000),
(32, 'Information Science & Engineering', 4500, 15000),
(33, 'Electrical & Electronics Engineering', 5000, 20000),
(34, 'Electronics & Communication Engineering', 4000, 20000),
(35, 'Mechanical Engineering', 900, 5000);

--
-- Triggers `branch`
--
DELIMITER $$
CREATE TRIGGER `deletebranch` AFTER DELETE ON `branch` FOR EACH ROW INSERT INTO deletebranch
VALUES (old.branch_id,old.branch_name,old.cut_of_start,old.cut_of_end)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `collage`
--

CREATE TABLE `collage` (
  `coll_id` int(10) NOT NULL,
  `branch_id` int(10) NOT NULL,
  `coll_name` varchar(50) NOT NULL,
  `adress` varchar(100) NOT NULL,
  `phone_no` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `collage`
--

INSERT INTO `collage` (`coll_id`, `branch_id`, `coll_name`, `adress`, `phone_no`) VALUES
(101, 11, 'National Institute of Engineering', 'Mananthavadi Rd, Vidyaranyapura, Mysuru, Karnataka 570008', 821248475),
(101, 12, 'National Institute of Engineering', 'Mananthavadi Rd, Vidyaranyapura, Mysuru, Karnataka 570008', 821248475),
(101, 13, 'National Institute of Engineering', 'Mananthavadi Rd, Vidyaranyapura, Mysuru, Karnataka 570008', 821248475),
(101, 14, 'National Institute of Engineering', 'Mananthavadi Rd, Vidyaranyapura, Mysuru, Karnataka 570008', 821248475),
(101, 15, 'National Institute of Engineering', 'Mananthavadi Rd, Vidyaranyapura, Mysuru, Karnataka 570008', 821248475),
(101, 16, 'National Institute of Engineering', 'Mananthavadi Rd, Vidyaranyapura, Mysuru, Karnataka 570008', 821248475),
(101, 17, 'National Institute of Engineering', 'Mananthavadi Rd, Vidyaranyapura, Mysuru, Karnataka 570008', 821248475),
(102, 21, 'JSS Science and Technology University', 'Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006', 821367899),
(102, 22, 'JSS Science and Technology University', 'Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006', 821367899),
(102, 23, 'JSS Science and Technology University', 'Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006', 821367899),
(102, 24, 'JSS Science and Technology University', 'Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006', 821367899),
(102, 25, 'JSS Science and Technology University', 'Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006', 821367899),
(102, 26, 'JSS Science and Technology University', 'Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006', 821367899),
(102, 27, 'JSS Science and Technology University', 'Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006', 821367899),
(102, 28, 'JSS Science and Technology University', 'Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006', 821367899),
(103, 31, 'NIE Institute of Technology', 'No 50, Koorgalli Village, Hootagalli Industrial Area, next to BEML, Mysuru, Karnataka 570018', 821234334),
(103, 32, 'NIE Institute of Technology', 'No 50, Koorgalli Village, Hootagalli Industrial Area, next to BEML, Mysuru, Karnataka 570018', 821234334),
(103, 33, 'NIE Institute of Technology', 'No 50, Koorgalli Village, Hootagalli Industrial Area, next to BEML, Mysuru, Karnataka 570018', 821234334),
(103, 34, 'NIE Institute of Technology', 'No 50, Koorgalli Village, Hootagalli Industrial Area, next to BEML, Mysuru, Karnataka 570018', 821234334);

-- --------------------------------------------------------

--
-- Table structure for table `deletebranch`
--

CREATE TABLE `deletebranch` (
  `branch_id` int(10) NOT NULL,
  `branch_name` varchar(80) NOT NULL,
  `cut_of_start` int(10) NOT NULL,
  `cut_of_end` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deletebranch`
--

INSERT INTO `deletebranch` (`branch_id`, `branch_name`, `cut_of_start`, `cut_of_end`) VALUES
(41, 'mech', 700, 3000);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `message`) VALUES
(1, 'pavan reddy', 'ppavankumarreddy20@gmail.com', 'bejxbejxbjexbeh'),
(5, 'vinay kumar', 'vinay@gmail.com', 'kbdz');

-- --------------------------------------------------------

--
-- Table structure for table `placement`
--

CREATE TABLE `placement` (
  `coll_id` int(10) NOT NULL,
  `branch_id` int(10) NOT NULL,
  `no_of_students_placed` int(10) NOT NULL,
  `year` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `placement`
--

INSERT INTO `placement` (`coll_id`, `branch_id`, `no_of_students_placed`, `year`) VALUES
(101, 11, 30, 2019),
(101, 12, 20, 2019),
(101, 13, 18, 2019),
(101, 14, 10, 2019),
(101, 15, 7, 2019),
(101, 16, 16, 2019),
(101, 17, 10, 2019),
(102, 21, 32, 2019),
(102, 22, 23, 2019),
(102, 23, 15, 2019),
(102, 24, 18, 2019),
(102, 25, 9, 2019),
(102, 26, 10, 2019),
(102, 27, 11, 2019),
(102, 28, 13, 2019),
(103, 31, 25, 2019),
(103, 32, 18, 2019),
(103, 33, 14, 2019),
(103, 34, 10, 2019),
(103, 35, 10, 2019);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `coll_id` int(10) NOT NULL,
  `rating` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`coll_id`, `rating`) VALUES
(101, 4.8),
(102, 4.5),
(103, 4.1);

-- --------------------------------------------------------

--
-- Table structure for table `userregister`
--

CREATE TABLE `userregister` (
  `id` int(11) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `phone_no` bigint(10) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `cet_rank` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userregister`
--

INSERT INTO `userregister` (`id`, `fname`, `lname`, `phone_no`, `email_id`, `password`, `cet_rank`) VALUES
(1, 'pavan', 'reddy', 2147483647, 'ppavankumarreddy20@gmail.com', 'pavan654', 33000),
(6, 'vikas', 'hk', 12345678, 'vikas@gmail.com', 'vikas123', 20000),
(7, 'pavan', 'reddy', 2345678, 'ppavankumarreddy@gmail.com', 'pavan123', 30000),
(14, 'vinay', 'kumar', 6361731795, 'vinay@gmail.com', 'vinay', 32000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`coll_id`,`branch_id`),
  ADD KEY `fkyadmission` (`branch_id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `collage`
--
ALTER TABLE `collage`
  ADD PRIMARY KEY (`coll_id`,`branch_id`),
  ADD KEY `fkycollage` (`branch_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `placement`
--
ALTER TABLE `placement`
  ADD PRIMARY KEY (`coll_id`,`branch_id`),
  ADD KEY `fkyplacement1` (`branch_id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`coll_id`);

--
-- Indexes for table `userregister`
--
ALTER TABLE `userregister`
  ADD PRIMARY KEY (`id`,`cet_rank`),
  ADD UNIQUE KEY `phone_no` (`phone_no`),
  ADD UNIQUE KEY `email_id` (`email_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminlogin`
--
ALTER TABLE `adminlogin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `userregister`
--
ALTER TABLE `userregister`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admission`
--
ALTER TABLE `admission`
  ADD CONSTRAINT `fkyadmission` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fkyadmission1` FOREIGN KEY (`coll_id`) REFERENCES `collage` (`coll_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `collage`
--
ALTER TABLE `collage`
  ADD CONSTRAINT `fkycollage` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `placement`
--
ALTER TABLE `placement`
  ADD CONSTRAINT `fkyplacement` FOREIGN KEY (`coll_id`) REFERENCES `collage` (`coll_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fkyplacement1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rating`
--
ALTER TABLE `rating`
  ADD CONSTRAINT `fkyrating` FOREIGN KEY (`coll_id`) REFERENCES `collage` (`coll_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
