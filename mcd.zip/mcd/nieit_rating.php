<?php
include("connection.php");
?>

<html>
<head>
<title>NIEIT-RATING</title>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" integrity="sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp" crossorigin="anonymous">
    <style>
 body {
            padding: 0;
            margin: 0;
        }

.heading {
  font-size: 25px;
  margin-right: 25px;
}

.fa {
  font-size: 25px;
}

.checked {
  color: orange;
}

/* Three column layout */
.side {
  float: left;
  width: 15%;
  margin-top:10px;
}

.middle {
  margin-top:10px;
  float: left;
  width: 70%;
}

/* Place text to the right */
.right {
  text-align: right;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* The bar container */
.bar-container {
  width: 100%;
  background-color: #f1f1f1;
  text-align: center;
  color: white;
}

/* Individual bars */
.bar-5 {width: 60%; height: 18px; background-color: #4CAF50;}
.bar-4 {width: 30%; height: 18px; background-color: #2196F3;}
.bar-3 {width: 10%; height: 18px; background-color: #00bcd4;}
.bar-2 {width: 4%; height: 18px; background-color: #ff9800;}
.bar-1 {width: 15%; height: 18px; background-color: #f44336;}

/* Responsive layout - make the columns stack on top of each other instead of next to each other */
@media (max-width: 400px) {
  .side, .middle {
    width: 100%;
  }
  .right {
    display: none;
  }
}
       .co {
            width: 100%;
            height: 300px;
        } 
        #logo {
            position: relative;
            bottom: 100px;
            left: 5px;
            border-radius: 10px;
             
        }
        h1{
            
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
           
        } 
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
            margin-left: 60px;
        }
       /* #b,#r {
            margin-left: 30px;
        } */
        #r {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        
        }
         a:hover {
            color: red;
              border-bottom:solid 3px red;
              padding-bottom: 10px;
        }
           a {
            text-decoration: none;
            color: black;
        
        }
       table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 200px;
            margin-top: 50px;
            margin-bottom: 50px;
             font-family: arial, sans-serif;
             
        }
        td, th {
           border: 2px solid #ddd;
           text-align: center;
           padding: 8px;
        }
        tr:hover {
            background-color: #ddd;
            color: red;
        }
        th {
            background-color: green;
            color: whitesmoke;
        }
        .a {
            position: relative;
            left: 30px;
        }
        .rating {
            margin: 50px;
            margin-bottom: 40px;
            padding: 20px;
            border-radius: 10px;
             border: 1px dotted green;
            /* box-shadow: 0 20px 20px 0 rgba(0,0,0,0.60), 10px 17px 50px 30px rgba(0,0,0,0.30); */
        }
        h2 {
            background-color: blueviolet;
            color: yellow;
            padding: 5px;
            border-radius: 7px;
            width: 29px;
        }
                    h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
            
        }
</style> 
</head> 
<body>
<div>
 <div class="co">
<img id="im" src="Primary%20NIE.jpg" alt="nie it" width="100%" height="300">
<div><h1>NIE INSTITUTE OF TECHNOLOGY,MYSURU</h1>
<h3>No 50, Koorgalli Village, Hootagalli Industrial Area, next to BEML, Mysuru, Karnataka 570018 - 821234334</h3></div></div>
<div>
<ul type='none'>
<li id="n"><a href="nieit_info.php">INFO</a></li> 
<li id="b"><a href="nieit_branch.php">BRANCH</a></li>
<li id="g"><a href="nieit_gallary.php">GALLERY</a></li>
<li id="r"><a href="nieit_placement.php">RATING</a></li>
</ul>
</div>
</div>
<div class="rating">
<span class="heading">COLLAGE RATING</span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star checked"></span>
<span class="fa fa-star"></span>
<?php
$sql = "select * from rating where coll_id=103";
$res= mysqli_query($conn, $sql);
if(mysqli_num_rows($res) != 0) {
    while($row = mysqli_fetch_assoc($res)) {
        echo "<h2>".$row['rating']."</h2>";
    } 
} 
else
{
    echo "0 results";
}
mysqli_close($conn); 
?><em>average based on 254 reviews.</em>
<hr style="border:3px solid #f1f1f1">

<div class="row">
  <div class="side">
    <div>5 star</div>
  </div>
  <div class="middle">
    <div class="bar-container">
      <div class="bar-5"></div>
    </div>
  </div>
  <div class="side right">
    <div>150</div>
  </div>
  <div class="side">
    <div>4 star</div>
  </div>
  <div class="middle">
    <div class="bar-container">
      <div class="bar-4"></div>
    </div>
  </div>
  <div class="side right">
    <div>63</div>
  </div>
  <div class="side">
    <div>3 star</div>
  </div>
  <div class="middle">
    <div class="bar-container">
      <div class="bar-3"></div>
    </div>
  </div>
  <div class="side right">
    <div>15</div>
  </div>
  <div class="side">
    <div>2 star</div>
  </div>
  <div class="middle">
    <div class="bar-container">
      <div class="bar-2"></div>
    </div>
  </div>
  <div class="side right">
    <div>6</div>
  </div>
  <div class="side">
    <div>1 star</div>
  </div>
  <div class="middle">
    <div class="bar-container">
      <div class="bar-1"></div>
    </div>
  </div>
  <div class="side right">
    <div>20</div>
  </div>
</div>
</div>
</body>
</html>