<?php
include("connection.php");
?>

<html>
<head>
<title>NIEIT-BRANCH</title>
    <style>
                body {
            padding: 0;
            margin: 0;
        }
    .co {
            width: 100%;
            height: 300px;
        }
        h1{
            
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
        } 
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
        }
       /* #b,#r {
            margin-left: 30px;
        } */
        
        #b {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        }
        a:hover {
            color: red;
             border-bottom:solid 3px red;
             padding-bottom: 10px;
        } 
        
           a {
            text-decoration: none;
            color: black;
               
        
        }
        li {
            margin-left: 60px;
        } 
       table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 200px;
            margin-top: 50px;
            margin-bottom: 50px;
             font-family: arial, sans-serif;
            background-image: linear-gradient(to bottom, lightgray , yellow);
             
        }
        td, th {
           border: 2px solid black;
           text-align: center;
           padding: 8px;
        }
        tr:hover {
            background-color: #ddd;
            color: red;
        }
        th {
            background-color: black;
            color: whitesmoke;
        } 
          h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
            
        }
    </style> 
</head> 
<body>
<div>
 <div class="co">
<img id="im" src="Primary%20NIE.jpg" alt="nie it" width="100%" height="300">
<div><h1>NIE INSTITUTE OF TECHNOLOGY,MYSURU</h1>
<h3>No 50, Koorgalli Village, Hootagalli Industrial Area, next to BEML, Mysuru, Karnataka 570018 - 821234334</h3>
</div></div>
<div>
<ul type='none'>
<li id="n"><a href="nieit_info.php">INFO</a></li> 
<li id="b"><a href="nieit_branch.php">BRANCH</a></li>
<li id="g"><a href="nieit_gallary.php">GALLERY</a></li>
<li id="r"><a href="nieit_rating.php">RATING</a></li>
</ul>
    </div>
<div class="table">
<table cellpadding=5>
<tr>
<th>BRANCH_ID</th>
<th>BRANCH_NAME</th>
<th colspan="2">PREVIOUS YEAR CUTOFF</th>
</tr>
<?php 
$sql = "select * from branch b, collage c where b.branch_id=c.branch_id and coll_id=103";
$res = mysqli_query($conn, $sql);
if(mysqli_num_rows($res) != 0) {
    while($row = mysqli_fetch_assoc($res)) {
        echo "<tr>";  
       echo   "<td>"."<a href=nieit_admission.php>".$row['branch_id']."</a>"."</td>" ;
        echo "<td>"."<a href=nieit_admission.php>".$row['branch_name']."</a>"."</td>";
         echo "<td>".$row['cut_of_start']."</td>";
         echo "<td>".$row['cut_of_end']."</td>"; 
    } 
} 
else
{
    echo "0 results" ;
}
mysqli_close($conn);
        ?>
    </table>
</div></div>
</body>
</html>