<html>
<head>
    <title>NIE-GALLERY</title>
    <style>
                body {
            padding: 0;
            margin: 0;
        }
       .co {
            width: 100%;
            height: 300px;
        } 
        #logo {
            position: relative;
            bottom: 100px;
            left: 5px;
            border-radius: 10px;
             
        }
      h1{
            
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
           
        }  
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
            margin-left: 60px;
        }
       /* #b,#g {
            margin-left: 30px;
        } */
        #g {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        
        }
         a:hover {
            color: red;
              border-bottom:solid 3px red;
              padding-bottom: 10px;
        }
           a {
            text-decoration: none;
            color: black;
        
        }
   .photos {
     width:280px;
     height: 200px;
     margin: 10px;
     border-radius:10px;
     margin-top: 30px;
           } 
    .photos:hover {
             box-shadow: 0 20px 20px 0 rgba(0,0,0,0.60), 10px 17px 50px 30px rgba(0,0,0,0.30);
      }
        h2 {
            text-align: center;
            background-color: aqua;
            margin-top: 50px;
            padding: 10px;
            border-radius: 30px 0px 30px 0px;
            margin-left: 20px;
            margin-right: 20px;
        }
        .gallary_photos {

          /*  margin-left: 60px; */
        }
         h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
            
        }

    </style>
    
    </head>
<body>
<div>
 <div class="co">
<img id="im" src="nie1.jpg" alt="nie it" width="100%" height="300">
<div><h1>The National Institute of Engineering</h1>
<h3>Mananthavadi Rd, Vidyaranyapura, Mysuru, Karnataka 570008 - 821345670</h3></div></div>
<div>
<ul type='none'>
<li id="n"><a href="nie_info.php">INFO</a></li> 
<li id="b"><a href="nie_branch.php">BRANCH</a></li>
<li id="g"><a href="nie_gallery.php">GALLERY</a></li>
<li id="r"><a href="nie_rating.php">RATING</a></li>
</ul>
</div>
</div>
<h2>CAMPUS</h2>
<div class="gallary_photos">
<img src="nie2.jpg" class="photos">
<img src="nie3.jpg" class="photos">
<img src="nie4.jpg" class="photos">
<img src="nie5.jpg" class="photos">
<img src="nie6.jpg" class="photos">
<img src="nie7.jpg" class="photos">
<img src="nie8.jpg" class="photos">
<img src="nie9.jpg" class="photos">
<img src="nie10.jpg" class="photos">
<img src="nie11.jpg" class="photos">
<img src="nie1.jpg" class="photos">
</div>
<h2>SPORTS DAY</h2>
<div class="gallary_photos">
<img src="niesportsday.jpg" class="photos">
<img src="niesportsday1.jpg" class="photos">
<img src="niesportsday2.jpg" class="photos">
<img src="niesportsday3.jpg" class="photos">
<img src="niesportsday4.jpg" class="photos">
</div>
<h2>CLASSROOM</h2>
<div class="gallary_photos">
<img src="nieclassroom.jpg" class="photos">
<img src="nieclassroom1.jpg" class="photos">
<img src="nieclassroom2.jpg" class="photos">
<img src="nieclassroom3.jpg" class="photos">
<img src="nieclassroom4.jpg" class="photos">
<img src="nieclassroom5.jpg" class="photos">
<img src="nieclassroom6.jpg" class="photos">
</div>
</body>
</html>