<html>
<head>
</head>
<body>
<?php 
echo "ppp89987p"
?>
<form></form>
<button onclick="but()">hi</button>
   <input type="text" height="70" width="70" required>
    </form>
</body>
</html>