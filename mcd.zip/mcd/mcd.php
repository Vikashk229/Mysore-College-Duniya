<html>
<head>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: url(im5.jpg);
            background-repeat: no-repeat;
            background-size: cover;
        }
        h1{
            overflow: hidden;
            white-space: nowrap; 
            animation: text 1s steps(30);
            width: 27.4ch;
            position: relative;
            left: 480px;
            color: yellow;
        }
        @keyframes text {
            0% {
                width: 0ch;
            }
            100% {
                width: 27.4ch;
             }
        }
        div {
            text-align: center;
            margin-top: 50px;
        }
        .p {
            border: 2px solid black;
            margin-top: 100px;
            margin-left: 25px;
            margin-right: 25px;
            line-height: 40px;
            border-radius: 10px;
            font-family: cursive;
            color: whitesmoke;
        }
        h2 {
            color: yellow;
        }
        .button {
  /*display: inline-block; */
  border-radius: 10px;
  background-color: whitesmoke;
  border: none;
  color: black;
  /*text-align: center; */
  font-size: 28px;
  padding: 15px;
  width: 200px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  position: relative;
  left: 800px;
  top: 100px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
    </style>
    </head>
<body>
    <div>
    <h2>WELLCOME TO</h2>
    <h1>MYSORE COLLEGE DUNIYA</h1>
    </div>
<div class="p"><p> "<em>MYSORE COLLEGE DUNIYA"</em> is related to Engineering Colleges of Mysore.
    <br>
    This is especially for 2nd Puc completed Students Because after completion of the 2nd Pu they will have confusion that which Engineering college is best, for our CET rank which college will assigbn and so many doubts... So we Planned that it may help some students to join for a good college and build Better future. Admins will give College Details which are situated in Mysore. After 2nd puc we also got some issues in joining the College  so students can easily get college the information.</p></div>
<a href="home.php" class="button" target="_blank"><span>Click here to view Colleges</span></a>
</body>
</html>