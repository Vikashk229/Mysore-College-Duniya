<?php
include("connection.php");
?>

<html>
<head>
<title>NIEIT-ADMISSION</title>
    <style>
        body {
            padding: 0;
            margin: 0;
        }
       .co {
            width: 100%;
            height: 300px;
        } 
        #logo {
            position: relative;
            bottom: 100px;
            left: 5px;
            border-radius: 10px;
             
        }
        h1{
            
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
           
        } 
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
            margin-left: 60px;
        }
       /* #b,#r {
            margin-left: 30px;
        } */
        #a {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        
        }
         a:hover {
            color: red;
              border-bottom:solid 3px red;
              padding-bottom: 10px;
        }
           a {
            text-decoration: none;
            color: black;
        
        }
       table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 200px;
            margin-top: 50px;
            margin-bottom: 50px;
             font-family: arial, sans-serif;
             
        }
        td, th {
           border: 2px solid black;
           text-align: center;
           padding: 8px;
        }
        th {
            background-color: black;
            color: whitesmoke;
        } 
       /*  tr:nth-child(2){
            background-color:paleturquoise;
             color: red;
        } */
           h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
            
        }
</style> 
</head> 
<body>
<div>
<div class="co">
<img id="im" src="Primary%20NIE.jpg" alt="nie it" width="100%" height="300">
<div><h1>NIE INSTITUTE OF TECHNOLOGY,MYSURU</h1>
<h3>No 50, Koorgalli Village, Hootagalli Industrial Area, next to BEML, Mysuru, Karnataka 570018 - 821234334</h3></div></div>
<div>
<ul type='none'>
<li id="n"><a href="nieit_info.php">INFO</a></li> 
<li id="b"><a href="nieit_branch.php">BRANCH</a></li>
<li id="g"><a href="nieit_gallary.php">GALLERY</a></li>
<li id="a"><a href="nieit_admission.php">ADMISSION</a></li>
<li id="p"><a href="nieit_placement.php">PLACEMENT</a></li>
<li id="r"><a href="nieit_rating.php">RATING</a></li>
</ul>
</div></div>
<table cellpadding=5>
<tr>
<th>BRANCH_NAME</th>
<th>NO_OF_STUDENTS_ADMITTED</th>
<th>YEAR</th>
</tr>
<?php 
$sql = "call adm1()";
$res= mysqli_query($conn, $sql);
if(mysqli_num_rows($res) != 0) {
    while($row = mysqli_fetch_assoc($res)) {
        echo "<tr>";  
        echo   "<td>".$row['branch_name']."</td>" ;
        echo "<td>".$row['no_of_students_admitted']."</td>";
        echo   "<td>".$row['year']."</td>" ;
    } 
} 
else
{
    echo "0 results" ;
}
mysqli_close($conn);
?>
    </table>
    </body>
</html>