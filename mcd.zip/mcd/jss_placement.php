<?php
include("connection.php");
?>

<html>
<head>
<title>JSS-PLACEMENT</title>
    <style>
        body {
            padding: 0;
            margin: 0;
        }
       .co {
            width: 100%;
            height: 300px;
        } 
        #logo {
            position: relative;
            bottom: 100px;
            left: 5px;
            border-radius: 10px;
             
        }
        h1{
            
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
           
        } 
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
            margin-left: 60px;
        }
       /* #b,#r {
            margin-left: 30px;
        } */
        #p {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        
        }
         a:hover {
            color: red;
              border-bottom:solid 3px red;
              padding-bottom: 10px;
        }
           a {
            text-decoration: none;
            color: black;
        
        }
       table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 200px;
            margin-top: 50px;
            margin-bottom: 50px;
             font-family: arial, sans-serif;
             
        }
        td, th {
           border: 2px solid black;
           text-align: center;
           padding: 8px;
        }
        th {
            background-color: black;
            color: whitesmoke;
        } 
       /*  tr:nth-child(2){
            background-color:paleturquoise;
             color: red;
        } */
        h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
        }
        .placement {
            background: url("company1.jpg");
            padding: 20px;
        }
        .placementlogo {
            margin-left: 17px;
        }
        .logoimg {
            border-radius: 10px;
            margin-left:15px;
            margin-top: 10px;
            
        }
        h2 {
            color: whitesmoke;
            font-family: cursive;
            font-size: 25px;
            background-color: black;
            padding: 10px;
            width: 162px;
            border-radius: 10px;
            margin-left: 530px;
        }
        #package {
            border: 2px solid red;
            width: 280px;
            padding: 10px;
            margin: 10px;
            border-radius: 10px;
            font-family: cursive;
            margin-left: 530px;
            padding-left: 15px;
        }
</style> 
</head> 
<body>
<div>
<div class="co">
<img id="im" src="jss1.png" alt="nie it" width="100%" height="300">
<div><h1>JSS Science and Technology University</h1>
<h3>Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006 - 821367899</h3></div></div>
<div>
<ul type='none'>
<li id="n"><a href="jss_info.php">INFO</a></li> 
<li id="b"><a href="jss_branch.php">BRANCH</a></li>
<li id="g"><a href="jss_gallery.php">GALLERY</a></li>
<li id="a"><a href="jss_admission.php">ADMISSION</a></li>
<li id="p"><a href="jss_placement.php">PLACEMENT</a></li>
<li id="r"><a href="jss_rating.php">RATING</a></li>
</ul>
</div></div>
<div class="placement">
    <h2>RECRUITERS</h2>
    <div class="placementlogo">
    <img src="jssplacementlogos.png"  height="500px" width="98%" class="logoimg">
 </div>
</div>
<table cellpadding=5>
<tr>
<th>BRANCH_NAME</th>
<th>NO_OF_STUDENTS_PLACED</th>
<th>YEAR</th>
</tr>
<?php 
$sql = "call plc1()";
$res= mysqli_query($conn, $sql);
if(mysqli_num_rows($res) != 0) {
    while($row = mysqli_fetch_assoc($res)) {
        echo "<tr>";  
        echo   "<td>".$row['branch_name']."</td>" ;
        echo "<td>".$row['no_of_students_placed']."</td>";
        echo   "<td>".$row['year']."</td>" ;
    } 
} 
else
{
    echo "0 results";
}
mysqli_close($conn);
?>
    </table>
    <div id="package">
    <p>Highest package : 22LAKH/ANNUM</p>
        <p>COMPANY : VISION WEB</p></div>
    </body>
</html>