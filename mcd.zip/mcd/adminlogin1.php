<?php
session_start();
include("connection.php");
if(isset($_POST['user_name']) && isset($_POST['password'])){
    
   /* function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    } */
    
    $name = $_POST['user_name'];
    $pass =  $_POST['password']; 
    
    if(empty($name)){
        header("Location: adminlogin.php?error=user_name is required");
        exit();
    }else if(empty($pass)){
        header("Location: adminlogin.php?error=Password is required");
        exit();
    }else{
        $sql = "SELECT * FROM adminlogin WHERE user_name='$name' AND password='$pass'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) === 1) {
          /*  $row = mysqli_fetch_assoc($result);
         if($row['emali_id'] === $email && $row['password'] === $pass){
            $_SESSION['email_id'] =$row['email_id'];
            $_SESSION['ID'] =$row['ID']; */
               header("Location: adminhome.php");
               exit();
         }else{
            header("Location: adminlogin.php?error=Incorrect user_name or Password");
            exit();
        }
    } 
}/* else{
            header("Location: userlogin.php?error=Incorrect email_id or Password");
        exit();
        }
        
    }
    
}else{
    header("Location: userlogin.php");
    exit();
} */