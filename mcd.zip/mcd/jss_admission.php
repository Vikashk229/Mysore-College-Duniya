<?php
include("connection.php");
?>

<html>
<head>
<title>JSS-ADMISSION</title>
    <style>
        body {
            padding: 0;
            margin: 0;
        }
       .co {
            width: 100%;
            height: 300px;
        } 
        #logo {
            position: relative;
            bottom: 100px;
            left: 5px;
            border-radius: 10px;
             
        }
        h1{
            
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
           
        } 
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
            margin-left: 60px;
        }
       /* #b,#r {
            margin-left: 30px;
        } */
        #a {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        
        }
         a:hover {
            color: red;
              border-bottom:solid 3px red;
              padding-bottom: 10px;
        }
           a {
            text-decoration: none;
            color: black;
        
        }
       table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 200px;
            margin-top: 50px;
            margin-bottom: 50px;
             font-family: arial, sans-serif;
             
        }
        td, th {
           border: 2px solid black;
           text-align: center;
           padding: 8px;
        }
        th {
            background-color: black;
            color: whitesmoke;
        } 
       /*  tr:nth-child(2){
            background-color:paleturquoise;
             color: red;
        } */
        h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
        }
</style> 
</head> 
<body>
<div>
<div class="co">
<img id="im" src="jss1.png" alt="nie" width="100%" height="300">
<div><h1>JSS Science and Technology University</h1>
<h3>Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006 - 821367899</h3></div></div>
<div>
<ul type='none'>
<li id="n"><a href="jss_info.php">INFO</a></li> 
<li id="b"><a href="jss_branch.php">BRANCH</a></li>
<li id="g"><a href="jss_gallery.php">GALLERY</a></li>
<li id="a"><a href="jss_admission.php">ADMISSION</a></li>
<li id="p"><a href="jss_placement.php">PLACEMENT</a></li>
<li id="r"><a href="jss_rating.php">RATING</a></li>
</ul>
</div></div>
<table cellpadding=5>
<tr>
<th>BRANCH_NAME</th>
<th>NO_OF_STUDENTS_ADMITTED</th>
<th>YEAR</th>
</tr>
<?php 
$sql = "call adm2()";
$res= mysqli_query($conn, $sql);
if(mysqli_num_rows($res) != 0) {
    while($row = mysqli_fetch_assoc($res)) {
        echo "<tr>";  
        echo   "<td>".$row['branch_name']."</td>" ;
        echo "<td>".$row['no_of_students_admitted']."</td>"; 
        echo   "<td>".$row['year']."</td>" ;
    } 
} 
else
{
    echo "0 results" ;
}
mysqli_close($conn);
?>
    </table>
    </body>
</html>