<?php
include("connection.php");
?>



<!DOCTYPE html>
<html>
<head>
<title>ADMIN-BRANCH</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
    background: url(ab1.jpeg);
    background-repeat: no-repeat;
    background-size: cover;
     }

/* Full-width input fields */
input, select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
 margin: 8px 0px; 
  border: none;
  cursor: pointer;
   width: 100%;
    border-radius: 10px;
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.container {
  padding: 10px;
  border-radius: 10px; 
  
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  padding-top: 100px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
  border-radius: 10px;
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  } 
  .cancelbtn {
     width: 100%;
  }
}
    .blood {
        margin-left: 50px;
    }
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  appearance: none;
  margin: 0;
}
 table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 150px;
            margin-top: 50px;
            margin-bottom: 50px;
             font-family: arial, sans-serif; 
             
        }
        td, th {
           border: 2px solid #ddd;
           text-align: center;
           padding: 8px;
        }
        th {
            background-color: green;
            color: whitesmoke;
        }
    .move {
        margin-left: 150px;
    }
    a {
        text-decoration: none;
        background-color: red;
        padding: 10px;
        position: relative;
        top: 10px;
        border-radius: 10px;
        color: white;
        
    }
</style>
</head>
<body>

<a href="adminhome.php">BACK</a>
<div class="move">
<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="blood">ADD</button> 
<button onclick="document.getElementById('id02').style.display='block'" style="width:auto;" class="blood">UPDATE</button> 
<button onclick="document.getElementById('id03').style.display='block'" style="width:auto;" class="blood">DELETE</button>
<button onclick="document.getElementById('id04').style.display='block'" style="width:auto;" class="blood">DISPLAY</button>
</div>
<div id="id01" class="modal"> 
<form class="modal-content animate" action="" method="post">
    <div class="container">
      <input type="number" placeholder="BRANCH_ID" name="branch_id" required>
      <input type="text" placeholder="BRANCH_NAME" name="branch_name" required>
      <input type="number" placeholder="CUT_OF_START" name="start" required>
      <input type="number" placeholder="CUT_OF_END" name="end" required>
        
      <button type="submit" name="insert">ADD</button>

    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
    </div>
  </form>
</div>
<!--add php -->
<div>
  <?php
    if(isset($_POST['insert'])) {
       $id = $_POST['branch_id'];
       $name = $_POST['branch_name'];
        $start = $_POST['start'];
        $end = $_POST['end'];
    $query = "insert into branch values('$id','$name','$start','$end')";
    $result = mysqli_query($conn, $query);
    if($result) 
    {
        echo '<script type="text/javascript"> alert("Record inserted")</script>';
    } else {
        echo '<script type="text/javascript"> alert("Record not inserted")</script>';
    }
    }
    ?> 
 </div>


<div id="id02" class="modal"> 
  
  <form class="modal-content animate" action="" method="post">

    <div class="container">
        <select>
       <?php
		$sql = "SELECT * FROM branch";
					$result = mysqli_query($conn, $sql);
					while($rows=mysqli_fetch_array($result))
		{ 
                      $row =  $rows['branch_id'];
          ?>
              <option value="<?php echo $row;?>"><?php echo $row;?></option>  
		<?php
		}
		?> 
    </select>

      <input type="text" placeholder="BRANCH_NAME" name="name" required>
         <input type="number" placeholder="CUT_OF_START" name="start" required>
      <input type="number" placeholder="CUT_OF_END" name="end" required>
        
      <button type="submit" name="update">UPDATE</button>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn">Cancel</button>
    </div>
  </form>
</div>
<div>
<?php

if(isset($_POST['update']))
{
    $query="UPDATE branch SET branch_name='$_POST[name]',cut_of_start='$_POST[start]',cut_of_end='$_POST[end]' where branch_id='$row'";
    $query_run=mysqli_query($conn,$query);
    
    if($query_run)
    {
     echo '<script types="text/javascript"> alert("Data Updated") </script>';
    }
    else
    {
    echo '<script types="text/javascript"> alert("Data Not Updated") </script>';
    }
} ?>
    </div>
<div id="id03" class="modal"> 
  
  <form class="modal-content animate" action="" method="post">

    <div class="container">
               <select>
       <?php
		$sql = "SELECT * FROM branch";
					$result = mysqli_query($conn, $sql);
					while($rows=mysqli_fetch_array($result))
		{ 
                        $row = $rows['branch_id'];
          ?>
              <option value="<?php echo $row; ?>"><?php echo $row;?></option>  
		<?php
		}
                   ?> 
        </select>
        
      <button type="submit" name="del">DELETE</button>
    </div>

    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id03').style.display='none'" class="cancelbtn">Cancel</button>
    </div>
  </form>
</div>
<div>
  <?php
    if(isset($_POST['del'])) {
    $query = "delete from branch where branch_id='$row'";
    $result = mysqli_query($conn, $query);
    if($result) 
    {
        echo '<script type="text/javascript"> alert("deleted")</script>';
    } else {
        echo  '<script type="text/javascript"> alert("Not deleted")</script>';
    }
    }
    ?>  
</div>
    
<div id="id04" class="modal">
<form class="modal-content animate">
    <div class="container">
     <table>
<tr>
<th>BRANCH_ID</th>
<th>BRANCH_NAME</th>
<th>CUT_OF_START</th>
<th>CUT_OF_END</th>
</tr>
<?php 
$sql = "select * from branch";
$res= mysqli_query($conn, $sql);
if(mysqli_num_rows($res) != 0) {
    while($row = mysqli_fetch_assoc($res)) {
        echo "<tr>";  
       echo   "<td>".$row['branch_id']."</td>" ;
        echo "<td>".$row['branch_name']."</td>";
        echo "<td>".$row['cut_of_start']."</td>";        
        echo "<td>".$row['cut_of_end']."</td>";
    } 
} 
else
{
    echo "0 results" ;
}
mysqli_close($conn);
        ?>
    </table>
    </div>
    <div class="container" style="background-color:#f1f1f1">
      <button type="button" onclick="document.getElementById('id04').style.display='none'" class="cancelbtn">Cancel</button>
    </div>
    </form>
</div>
<script>
// Get the modal
var modal = document.getElementById('id01');
var modal = document.getElementById('id02');
var modal = document.getElementById('id03');
var modal = document.getElementById('id04');
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</body>
</html>