<?php
include("connection.php");
?>

<html>
<head>
<title>NIEIT-PLACEMENT</title>
    <style>
        body {
            padding: 0;
            margin: 0;
        }
       .co {
            width: 100%;
            height: 300px;
        } 
        #logo {
            position: relative;
            bottom: 100px;
            left: 5px;
            border-radius: 10px;
             
        }
        h1{
            
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
           
        } 
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
            margin-left: 60px;
        }
       /* #b,#r {
            margin-left: 30px;
        } */
        #p {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        
        }
         a:hover {
            color: red;
              border-bottom:solid 3px red;
              padding-bottom: 10px;
        }
           a {
            text-decoration: none;
            color: black;
        
        }
       table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 200px;
            margin-top: 50px;
            margin-bottom: 50px;
             font-family: arial, sans-serif;
             
        }
        td, th {
           border: 2px solid black;
           text-align: center;
           padding: 8px;
        }
        th {
            background-color: black;
            color: whitesmoke;
        } 
       /*  tr:nth-child(2){
            background-color:paleturquoise;
             color: red;
        } */
            h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
            
        }
        .placement {
            background: url("company1.jpg");
            padding: 20px;
        }
        .placementlogo {
            margin-left: 17px;
        }
        .logoimg {
            border-radius: 10px;
            margin-left:25px;
            margin-top: 10px;
            
        }
        h2 {
            color: whitesmoke;
            font-family: cursive;
            font-size: 25px;
            background-color: black;
            padding: 10px;
            width: 162px;
            border-radius: 10px;
            margin-left: 530px;
        }
                #package {
            border: 2px solid red;
            width: 280px;
            padding: 10px;
            margin: 10px;
            border-radius: 10px;
            font-family: cursive;
            margin-left: 530px;
            padding-left: 15px;
        }
</style> 
</head> 
<body>
<div>
<div class="co">
<img id="im" src="Primary%20NIE.jpg" alt="nie it" width="100%" height="300">
<div><h1>NIE INSTITUTE OF TECHNOLOGY,MYSURU</h1>
<h3>No 50, Koorgalli Village, Hootagalli Industrial Area, next to BEML, Mysuru, Karnataka 570018 - 821234334</h3></div></div>
<div>
<ul type='none'>
<li id="n"><a href="nieit_info.php">INFO</a></li> 
<li id="b"><a href="nieit_branch.php">BRANCH</a></li>
<li id="g"><a href="nieit_gallary.php">GALLERY</a></li>
<li id="a"><a href="nieit_admission.php">ADMISSION</a></li>
<li id="p"><a href="nieit_placement.php">PLACEMENT</a></li>
<li id="r"><a href="nieit_rating.php">RATING</a></li>
</ul>
</div></div>
<div class="placement">
    <h2>RECRUITERS</h2>
    <div class="placementlogo">
    <img src="infosys.jpg" alt="infosys" height="100px" width="180px" class="logoimg">
    <img src="ibm.jpg" alt="ibm" height="100px" width="180px" class="logoimg">
    <img src="hcl.jpg" alt="hcl" height="100px" width="180px" class="logoimg">
    <img src="deltax.jpg" alt="deltax" height="100px" width="180px" class="logoimg">
    <img src="dell.jpg" alt="dell" height="100px" width="180px" class="logoimg">
    <img src="deloitee.jpg" alt="deloitte" height="100px" width="180px" class="logoimg">
    <img src="cognizent.jpg" alt="cognizent" height="100px" width="180px" class="logoimg">
    <img src="epsilon.png" alt="epsilon" height="100px" width="180px" class="logoimg">
    <img src="hashedin.jpg" alt="hashedin" height="100px" width="180px" class="logoimg">
    <img src="gl.jpg" alt="globallogic" height="100px" width="180px" class="logoimg">
    <img src="rsz_paypal.png" alt="globallogic" height="100px" width="180px" class="logoimg">
    <img src="download.png" alt="bosch" height="100px" width="180px" class="logoimg">
 </div>
</div>
<table cellpadding=5>
<tr>
<th>BRANCH_NAME</th>
<th>NO_OF_STUDENTS_PLACED</th>
<th>YEAR</th>
</tr>
<?php 
$sql = "call plc2()";
$res= mysqli_query($conn, $sql);
if(mysqli_num_rows($res) != 0) {
    while($row = mysqli_fetch_assoc($res)) {
        echo "<tr>";  
        echo   "<td>".$row['branch_name']."</td>" ;
        echo "<td>".$row['no_of_students_placed']."</td>";
        echo   "<td>".$row['year']."</td>" ;
    } 
} 
else
{
    echo "0 results";
}
mysqli_close($conn);
?>
    </table>
<div id="package">
<p>Highest package : 10LAKH/ANNUM</p>
    <p>COMPANY : IBM</p></div>
    </body>
</html>