<?php
 include("connection.php");
?>
 <?php
    if(isset($_POST['insert'])) {
       $fname = $_POST['fname'];
       $lname = $_POST['lname'];
       $num = $_POST['num'];
       $email = $_POST['email'];
       $pass = $_POST['password'];
       $cetnum = $_POST['cetnum'];
    $query = "insert into userregister values('','$fname','$lname','$num','$email','$pass','$cetnum')";
    $result = mysqli_query($conn, $query);
    if($result) 
    {
        echo '<script type="text/javascript"> alert("Registered Succesfully")</script>';
    } else {
        echo '<script type="text/javascript"> alert("Not Registereds")</script>';
    }
    }
    ?>