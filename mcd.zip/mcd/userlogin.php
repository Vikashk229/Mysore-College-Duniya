<!DOCTYPE html>
<html>
<head>
    <title>USER-LOGIN</title>
    <style>
    body{
    background-image: linear-gradient(19deg, #21D4FD 0%, #B721FF 100%);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 97vh;
    flex-direction: column;
}



form{
    width: 500px;
    border: 2px solid #ccc;
    padding: 30px;
    background: #fff;
    border-radius: 15px;   
}

h2{
    text-align: center;
    margin-bottom: 40px;    
}

input{
    display: block;
    border: 2px solid #ccc;
    width: 95%;
    padding: 10px;
    margin: 10px auto;
    border-radius: 5px;
        } 

button{
    background-color: white;
    padding: 10px 15px;
    color: green;
    border-radius: 5px;
    margin-left: 10px;
    border: 2px solid green;
    cursor: pointer;
}
button:hover{
    background-color: green;
    color: white;
}
.error{
    background: #F2DEDE;
    color: #A94442;
    padding: 10px;
    border-radius: 5px;
    position: relative;
    top:300px;
    z-index: 2;
   /* margin: 20px auto; */
} 
h1 {
    text-align: center;
    color: #fff;
}
.admin{
    background: #555;
    padding: 10px 15px;
    color: #fff;
    border-radius: 5px;
    border: none;
     text-decoration: none;
}
.admin:hover {
    opacity: .7;
}
        div {
            float: right;
            position: relative;
            left: 630px;
            bottom:140px;
        }
       .forgot { 
           color: blue;
           float: right;
           margin-top: 10px;
        }
        .back {
            background: #555;
            padding: 10px 15px;
             color: #fff;
             border-radius: 5px;
            border: none;
            text-decoration: none;
            margin-right: 1280px;
            position: relative;
            bottom: 100px;
            
        } 
    </style>
    </head>
<body>
   <a href="userregister.php" class="back">BACK</a> 
    <div><a href="adminlogin.php" class="admin">ADMIN</a></div>
     <?php if(isset($_GET['error'])){
        $get = $_GET['error'];?>
    <?php echo "<script type='text/javascript'> alert('$get')</script>"; ?>
    <?php   } ?>
    <form action="userlogin1.php" method="post">
        <h2>LOGIN</h2>
     
        <input type="email" name="email" placeholder="EMAIL_ID" required><br>
        <input type="password" name="password" placeholder="Password" required><br>   
        
        <button type="submit">Login</button>
        <a href="forgot.php" class="forgot">Forgot password?</a>
    </form>        

</body>
</html>