<?php
$servername="localhost";
$username="root";
$password="";
$dbname="mcd";


$conn = mysqli_connect($servername,$username,$password,$dbname);

if($conn)
{
    echo "";
    
}
else 
{
    echo "not connected";
}
?>   
    