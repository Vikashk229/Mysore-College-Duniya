<?php
 include("connection.php");
?>
<html>
<head>
    <title>USER-REGISTER</title>
    <style>
        body {
            margin: 0;
            padding: 0;
                background-image: linear-gradient(19deg, #21D4FD 0%, #B721FF 100%);
        }
       /* div {
            height:700px;
            width: 100%;
            background: url("nie.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            position: fixed;
            animation: mcd 5s infinite;
        }  */
 input{
    display: block;
    border: 2px solid #ccc;
    width: 95%;
    padding: 10px;
    margin: 10px auto;
    border-radius: 5px;
        } 
       input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  appearance: none;
  margin: 0;
}
 input:focus {
  outline: none;
        }
        button {
            background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
            width: 100%;
  
        }
    button:hover {
  box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        }
        form {
            display:block;
            position: absolute;
            left: 430px;
            top: 60px;
             margin: 20px;
               width: 400px;
             padding: 16px;
             background-color: white;
            border-radius: 10px;
              box-shadow: 0 12px 16px 0 rgba(0,0,0,0.24),0 17px 50px 0 rgba(0,0,0,0.19);
        }
        h1 {
            text-align: center;
            font-family:monospace;
        }
  
        p {
            float: right;
        }
        a {
            margin-left: 5px;
            color: darkblue;
        }
  </style>
    </head>
<body>
  <div>
      <form action="" method="post">
    <h1>REGISTER</h1>
   <input type="text" name="fname" placeholder="First Name" required>
   <input type="text" name="lname" placeholder="Last Name" required>
   <input type="number" name="num" placeholder="Phone Number" required>
   <input type="email" name="email" placeholder="Email" required>
   <input type="password" name="password" placeholder="Password" required>
   <input type="number" name="cetnum" placeholder="CET Rank" required>
    <button name="insert">SUBMIT</button>
    <p>Already have an account<a href="userlogin.php">login here</a></p>
          </form>
    </div>
     <?php
    if(isset($_POST['insert'])) {
       $fname = $_POST['fname'];
       $lname = $_POST['lname'];
       $num = $_POST['num'];
       $email = $_POST['email'];
       $pass = $_POST['password'];
       $cetnum = $_POST['cetnum'];
    $query = "insert into userregister values('','$fname','$lname','$num','$email','$pass','$cetnum')";
    $result = mysqli_query($conn, $query);
    if($result) 
    {
        echo '<script type="text/javascript"> alert("Registered Succesfully")</script>';
    } else {
        echo '<script type="text/javascript"> alert("Not Registered")</script>';
    }
    }
    ?>
    </body>
</html>