<?php
session_start();
include("connection.php");
if(isset($_POST['email']) && isset($_POST['password'])){
    
   /* function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    } */
    
    $email = $_POST['email'];
    $pass =  $_POST['password']; 
    
    if(empty($email)){
        header("Location: userlogin.php?error=email is required");
        exit();
    }else if(empty($pass)){
        header("Location: userlogin.php?error=Password is required");
        exit();
    }else{
        $sql = "SELECT * FROM userregister WHERE email_id='$email' AND password='$pass'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) === 1) {
          /*  $row = mysqli_fetch_assoc($result);
         if($row['emali_id'] === $email && $row['password'] === $pass){
            $_SESSION['email_id'] =$row['email_id'];
            $_SESSION['ID'] =$row['ID']; */
               header("Location: mcd.php");
               exit();
         }else{
            header("Location: userlogin.php?error=Incorrect email_id or Password");
            exit();
        }
    } 
}/* else{
            header("Location: userlogin.php?error=Incorrect email_id or Password");
        exit();
        }
        
    }
    
}else{
    header("Location: userlogin.php");
    exit();
} */