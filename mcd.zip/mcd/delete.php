<?php 
    include("connection.php");
?>
    
<?php
    if(isset($_POST['delete'])) {
    $branchid = $_GET['branchid'];
    $sql = "delete from branch where branch_id='$branchid'";
    $result = mysqli_query($conn, $query);
    if($result) 
    {
        echo '<script type="text/javascript"> alert("deleted")</script>';
    } else {
        echo '<script type="text/javascript"> alert("not deleted")</script>';
    }
    }
    ?>