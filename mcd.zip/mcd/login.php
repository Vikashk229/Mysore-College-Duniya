<?php
include("connection.php");
?>
<html>
<head>
    <style>
        body {
            margin: 0;
            padding: 0;
        }
        div {
            height:700px;
            width: 100%;
            background: url("nie.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            position: fixed;
            animation: mcd 5s infinite;
        }
        @keyframes mcd {
            10% {
                background: url(nie.jpg);
                background-repeat: no-repeat;
            background-size: cover;
            position: fixed;
            }
            50% {
                background: url(jss.jpg);
                 background-repeat: no-repeat;
            background-size: cover;
            position: fixed;
            }
            100% {
                background: url(nieit1.jpg);
                 background-repeat: no-repeat;
            background-size: cover;
            position: fixed;
            }
        }
        input {
        width: 300px;
      padding: 12px 20px;
      margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
    border:none;
  background-color: gainsboro;
    
             display:block;
        }
       input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  appearance: none;
  margin: 0;
}
      /*  input[type=number] {
            appearance: none;
        } */
        input:focus {
            border: 1px solid red;
  outline: none;
        }
        button {
            background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  
        }
        form {
            display:block;
            position: absolute;
            left: 450px;
            top: 100px;
             margin: 20px;
            max-width: 300px;
             padding: 16px;
             background-color: white;
            border-radius: 10px;
        }
    </style>
    </head>
<body>
  <div>
      <form>
    <h1>LOGIN</h1>
   <input type="text" name="fname" placeholder="First Name" required>
   <input type="text" name="lname" placeholder="Last Name" required>
   <input type="number" name="num" placeholder="Phone Number" required>
   <input type="email" name="email" placeholder="Email" required>
   <input type="number" name="cetnum" placeholder="CET Rank" required>
    <button>LOGIN</button>
          </form>
    </div>
    </body>
</html>