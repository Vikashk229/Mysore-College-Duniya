<?php 
    include("connection.php");
?>
    
<html>
    <head>
    <style>
        input {
            margin: 20px;
            height: 40px;
            width: 150px;
        } 
        
        </style>
    
    
    </head>
<body>
 
 <form action="" method="POST">
   <input type="text" name="name" placeholder="name" required><br>
    <input type="text" name="usn" placeholder="USN"  required><br>
    <input type="text" name="sem" placeholder="sem"  required><br>
     <input type="submit" name="insert" value="insert" style="background-color:red";>
 </form>   
<?php
    if(isset($_POST['insert'])) {
       $name = $_POST['name'];
       $usn = $_POST['usn'];
       $sem = $_POST['sem'];
    $query = "insert into student values('','$name','$usn','$sem')";
    $result = mysqli_query($conn, $query);
    if($result) 
    {
        echo "data inserted";
    } else {
        echo "data not inserted";
    }
    }
    ?>
</body>
</html>