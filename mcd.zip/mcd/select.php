   <?php 
    include("connection.php");
?>
<html>
<body>

<?php 
$sql = "select * from student where sem=6";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) != 0) {
    while($row = mysqli_fetch_assoc($result)) {
        echo $row['id']."".$row['name']."".$row['usn']."".$row['sem']. "<br>";
    }
} 
else
{
    echo "0 results" ;
}
mysqli_close($conn);
  ?>
 
    </body>
    </html>