<?php 
$sql = "select adress, phone_no from collage where coll_id=103 and branch_id=31";
$res= mysqli_query($conn, $sql);
if(mysqli_num_rows($res) != 0) {
    while($row = mysqli_fetch_assoc($res)) {
        echo $row['adress']." - ".$row['phone_no'];
    }
} 
else
{
    echo "0 results" ;
}
mysqli_close($conn);
?>