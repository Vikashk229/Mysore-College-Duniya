<html>
<head>
   <title>JSS-INFO</title>
    <style>
        body {
            padding: 0;
            margin: 0;
        }
    .co {
            width: 100%;
            height: 300px;
        }
        #logo {
            position: relative;
            bottom: 100px;
            left: 5px;
            border-radius: 10px;
        }
        h1{
            
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
        } 
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
        }
       /* #b,#r {
            margin-left: 30px;
        } */
        
        #n {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        }
        a:hover {
            color: red;
             border-bottom:solid 3px red;
             padding-bottom: 10px;
        } 
        
           a {
            text-decoration: none;
            color: black;
               
        
        }
        li {
            margin-left: 60px;
        } 
        p{
            text-indent: 50px;
            text-align: justify;
        }
        .p  {
            font-family: cursive;
            padding: 30px;
        }
           table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 200px;
            margin-top: 50px;
            margin-bottom: 50px;
             font-family: arial, sans-serif;
               font-family: cursive;
             
        }
        td, th {
           border: 2px solid black;
           text-align: center;
           padding: 8px;
        }
        tr:hover {
            background-color: #ddd;
            color: red;
        }
        h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
        }
                 .ba {
             /*background-image: linear-gradient(to bottom right, red , blue); */
           /* background-image: linear-gradient(to right, rgba(255,0,0,0), rgba(255,0,0,1)); */
             background-image: linear-gradient(to bottom,  lightgray ,yellow);
            margin-top: 40px;

        }
        h2 {
            color: blueviolet;
        }
</style> </head> 
<body>
<div>
<div class="co">
<img  id="im" src="jss1.png" alt="nie" width="100%" height="300">
<div><h1>JSS Science and Technology University</h1>
<h3>Campus Roads, University Of Mysore Campus, Mysuru, Mysuru, Mysuru, Karnataka 570006 - 821367899</h3></div></div>
<div>
<ul type='none'>
<li id="n"><a href="jss_info.php">INFO</a></li> 
<li id="b"><a href="jss_branch.php">BRANCH</a></li>
<li id="g"><a href="jss_gallery.php">GALLERY</a></li>
<li id="r"><a href="jss_rating.php">RATING</a></li>
</ul>
</div>
<div class="ba">
<div class="p">
   <p>JSS Science and Technology University [JSS STU] is a well-renowned private institute and has been approved by AICTE and UGC. With a sprawling 102 acres campus filled with state-of-the-art facilities. It provides various undergraduate, postgraduate, and Ph.D. programs with multiple specializations under every course.  Admission procedure takes place online after the results for the various entrance exams have been announced. Apart from studies the institute also focuses on the extra-curricular growth of its students and has various student clubs, fests, and sports facilities available for them.</p> 
<div>
    <h2>JSS Science and Technology University Highlights:</h2>
    <table>
    <tr>
    <td>Established</td>
    <td>1963</td></tr>
    <tr>
    <td>Type</td>
    <td>Private</td>
    </tr>
    <tr>
    <td>Approval</td>
    <td>AICTE and UGC</td>
    </tr>
   <!-- <tr>
    <td>Affiliation</td>
    <td> SCTIMST , University of Madras</td>
    </tr> -->
    <tr>
    <td>Popular Courses</td>
    <td>BE, M.Tech, MBA</td>
    </tr>
    <tr>
    <td>Official Website</td>
  <td> <a href="http://jssstuniv.in/" target="_blank">http://jssstuniv.in/</a> </td>
    </tr>
    </table>
    
    
    </div>
</div>
</div>
    </div>
</body>
</html>