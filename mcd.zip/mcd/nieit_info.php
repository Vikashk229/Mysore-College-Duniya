<?php
include("connection.php");
?>

<html>
<head>
   <title>NIEIT-INFO</title>
    <style>
        body {
            padding: 0;
            margin: 0;
        }
    .co {
            width: 100%;
            height: 300px;
        }
        h1{ 
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
        } 
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
        }
       /* #b,#r {
            margin-left: 30px;
        } */
        
        #n {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        }
        a:hover {
            color: red;
             border-bottom:solid 3px red;
             padding-bottom: 10px;
        } 
        
           a {
            text-decoration: none;
            color: black;
               
        
        }
        li {
            margin-left: 60px;
        } 
        p{
            text-indent: 50px;
            text-align: justify;
            font-family: cursive;
        }
        .p  {
            /* box-shadow: 5px 10px 18px #888888; */
            padding: 30px;
        }
           table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 200px;
            margin-top: 10px;
            margin-bottom: 50px;
             font-family: arial, sans-serif;
             
        }
        td, th {
           border: 2px solid black;
           text-align: center;
           padding: 8px;
            font-family: cursive;
            
        }
        tr:hover {
            background-color: #ddd;
            color: red;
        }
        .ba {
             /*background-image: linear-gradient(to bottom right, red , blue); */
           /* background-image: linear-gradient(to right, rgba(255,0,0,0), rgba(255,0,0,1)); */
             background-image: linear-gradient(to bottom,  lightgray ,yellow);
            margin-top: 40px;

        } 
        h2 {
            color: blueviolet;
        }
        h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
            
        }
</style> </head> 
<body>
<div>
<div class="co">
<img  id="im" src="Primary%20NIE.jpg" alt="nie it" width="100%" height="300">
<div><h1>NIE INSTITUTE OF TECHNOLOGY,MYSURU</h1>
<h3>No 50, Koorgalli Village, Hootagalli Industrial Area, next to BEML, Mysuru, Karnataka 570018 - 821234334</h3></div></div>
<div>
<ul type='none'>
<li id="n"><a href="nieit_info.php">INFO</a></li> 
<li id="b"><a href="nieit_branch.php">BRANCH</a></li>
<li id="g"><a href="nieit_gallary.php">GALLERY</a></li>
<li id="r"><a href="nieit_rating.php">RATING</a></li>
</ul>
</div>
<div class="ba">
<div class="p">
   <p>NIE Institute of Technology was established in the year 2008 as a sister college of the prestigious NIE with a vision of imparting value-added technical education to prepare the next generation engineers of our nation. Popularly known as NIEIT, it is located in the Heritage City of Karnataka – Mysuru. NIEIT is spread over 25 acres of lush green campus surrounded by industrial giants like Infosys, BEML, L&T and Skanray. NIEIT is affiliated to VTU, Belagavi, and approved by AICTE, New Delhi. 
   NIEIT offers five engineering programs such as Electrical & Electronics Engineering, Mechanical Engineering, Electronics & Communication Engineering, Computer Science & Engineering and Information Science & Engineering. The institution has a fine blend of students from various parts of Karnataka and from other states. The teaching staff who form the core of this institution are dedicated, enthusiastic and highly qualified. Well – equipped laboratories along with scientific teaching methodologies provide a solid platform for the students to learn and grow independently. The institution is proud to have various student clubs, technical and cultural forums that make the students versatile. With the synergy between the management, teaching, technical and non – teaching staff, NIEIT seeks to produce creative and technically sound engineers who are motivated to address the existing problems and also foresee the opportunities to change our society for the good.</p> 
<div>
 <h2>NIE Institute of Technology Highlights:</h2>
    <table>
    <tr>
    <td>Established</td>
    <td>2008</td></tr>
    <tr>
    <td>Type</td>
    <td>Private</td>
    </tr>
    <tr>
    <td>Approval</td>
    <td>AICTE</td>
    </tr>
    <tr>
    <td>Affiliation</td>
    <td>VTU</td>
    </tr>
    <tr>
    <td>Popular Courses</td>
    <td>BE, M.Tech</td>
    </tr>
    <tr>
    <td>Official Website</td>
  <td> <a href="http://www.nieit.ac.in/" target="_blank">http://www.nieit.ac.in/</a> </td>
    </tr>
    </table>
    
    
    </div>
</div>
</div></div>
</body>
</html>