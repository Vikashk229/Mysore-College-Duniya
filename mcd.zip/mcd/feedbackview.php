<?php
include("connection.php");
?>

<html>
<head>
   <style>
       body {
           background: url(ab1.jpeg);
    background-repeat: no-repeat;
    background-size: cover;
       }
    table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 150px;
            margin-top: 50px;
            margin-bottom: 50px;
             font-family: arial, sans-serif; 
             
        }
        td, th {
           border: 2px solid black;
           text-align: center;
           padding: 8px;
            background-color: #ddd;
        }
        th {
            background-color: green;
            color: whitesmoke;
        }
        a {
        text-decoration: none;
        background-color: red;
        padding: 10px;
        position: relative;
        top: 10px;
        border-radius: 10px;
        color: white;
        
    }
    </style> 
    </head>
<body>
<a href="adminhome.php">BACK</a>
<table>
<tr>
<th>NAME</th>
<th>EMAIL</th>
<th>FEEDBACK</th>
</tr>
<?php 
$sql = "select * from feedback";
$res= mysqli_query($conn, $sql);
if(mysqli_num_rows($res) != 0) {
    while($row = mysqli_fetch_assoc($res)) {
        echo "<tr>";  
        echo   "<td>".$row['name']."</td>" ;
       echo   "<td>".$row['email']."</td>" ;
        echo "<td>".$row['message']."</td>"; 
    } 
} 
else
{
    echo "0 results" ;
}
mysqli_close($conn);
        ?>
    </table>
    </body>
</html>