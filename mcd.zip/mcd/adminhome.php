<html>
<head>
<title>ADMIN-HOME</title>
<style>
    body{
        margin: 0;
        padding: 0;
        background: url(back.jpeg);
        background-repeat: no-repeat;
        background-size: cover;
    }
   button {
  background-image: linear-gradient(to right, darkorange,white,green);
  color: black;
    padding: 14px 20px;
  margin: 8px 250px;
  border: 0 50px 0 50px;
  border-radius: 20px 0 20px 0;
  cursor: pointer;
  width: 60%;
       font-family: cursive;
       font-size: 25px;
}

button:hover {
  /*opacity: 0.8;*/
 /*background-image: linear-gradient(to bottom, gray,yellow); */
    color: blue;
} 
    div {
        margin-top: 100px;
    }
    </style>
    </head>
<body>
  <div>
 <a href="admin_branch.php"><button>BRANCH</button></a>
  <a href="admin_college.php"><button>COLLEGE</button></a>
      <a href="admin_admission.php"><button>ADMISSION</button></a>
      <a href="admin_placement.php"><button>PLACEMENT</button></a>
      <a href="admin_rating.php"><button>RATING</button></a>
      <a href="feedbackview.php"><button>FEEDBACK</button></a>
    </div>
</body>
</html>