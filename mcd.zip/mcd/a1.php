<html>

<body>
    <div>
    
   <ul> 
 <li><a href="#">dash</a></li>
       <li><a href="addman.php">add manager</a></li>
       <li><a href="">all manager</a></li>
       <li><a href="">add pharam</a></li>
       <li><a href=""> all pharam</a></li>
       <li><a href="">add sell</a></li>
       <li><a href=""> all sell</a></li>
       
        </ul>       
    </div>
        
    
    
    
    </body>







</html>