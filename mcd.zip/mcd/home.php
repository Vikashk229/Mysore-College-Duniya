<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>


body { 
  margin: 0;
    padding: 0;
  font-family: Arial, Helvetica, sans-serif;
       background:url(college1.jpg);
    
}

.header {
  overflow: hidden;
 background-color: black; 
    border-bottom: 2px solid grey;
  padding: 20px 10px;
}

.header a {
  float: left;
  color: whitesmoke;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px; 
  line-height: 25px;
  border-radius: 4px;
}

.header a.logo {
  font-size: 25px;
  font-weight: bold;
    font-family: cursive;
}
.header a:hover {
  color: yellowgreen;
}

 .header a.feedback {
     background-color: whitesmoke;
      color: black;
     border: 2px solid red;
     border-radius: 10px;
}
   .header a.feedback:hover {
        background-color: red;
        color: whitesmoke;
    }

.header-right {
  float: right;
}

 @media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left; 
  }
  
  .header-right {
    float: none;
  }
}
    img {
        float: left;
        margin-top: 20px;
        border-radius: 10px;
      
    } 
    img:hover {
         box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }
    ul {
        display: block;
        margin-left: 100px;
    }
    li{
        display: inline;
    }
    li a{
        text-decoration: none;
        background-color: aliceblue;
        color: black;
        padding: 8px;
        border: 2px solid red;
        margin: 10px;
        border-radius: 8px;
    }
    li a:hover {
        background-color: red;
        color: white;
         box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    }
    .clg {
      /* margin: 30px; */
       /* background-color: aqua; */
        padding: 15px;
      /*  margin-left: 50px;
        margin-right: 50px; */
        padding-left: 200px;
    }
    .clg:hover {
       /* background-color: #ddd; */
     box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); 
    }
    h1 {
        margin-left: 100px;
    }
    h1 a {
        text-decoration: none;
        color: whitesmoke;
    }
</style>
</head>
<body>

<div class="header">
  <a href="home.php" class="logo">MYSORE COLLEGE DUNIYA</a>
  <div class="header-right">
   <a href="feedback.php" class="feedback" target="_blank">FEEDBACK</a>
  </div>
</div>
<div class="div">
<div  class="clg">
 <h1><a href="nie_info.php" target="_blank">THE NATIONAL INSTITUTE OF ENGINEERING</a></h1>
<ul type="none">
  <li><a href="nie_info.php" target="_blank">HOME</a></li>
  <li><a href="nie_branch.php" target="_blank">BRANCH</a></li>
  <li><a href="nie_admission.php" target="_blank">ADMISSION</a></li>
  <li><a href="nie_placement.php" target="_blank">PLACEMENT</a></li>
    </ul>
</div>
    <div  class="clg">
  <h1><a href="nieit_info.php" target="_blank">NIE INSTITUTE OF TECHNOLOGY</a></h1>
<ul type="none">
  <li><a href="nieit_info.php" target="_blank">HOME</a></li>
  <li><a href="nieit_branch.php" target="_blank">BRANCH</a></li>
  <li><a href="nieit_admission.php" target="_blank">ADMISSION</a></li>
  <li><a href="nieit_placement.php" target="_blank">PLACEMENT</a></li>
    </ul>
</div>
    <div  class="clg">
  <h1><a href="jss_info.php" target="_blank">JSS Science and Technology University</a></h1>
<ul type="none">
  <li><a href="jss_info.php" target="_blank">HOME</a></li>
  <li><a href="jss_branch.php" target="_blank">BRANCH</a></li>
  <li><a href="jss_admission.php" target="_blank">ADMISSION</a></li>
  <li><a href="jss_placement.php" target="_blank">PLACEMENT</a></li>
    </ul>
</div>
</div>
</body>
</html>