<!DOCTYPE html>
<html>
<head>
    <title>ADMIN-LOGIN</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
    body{
    background-image: linear-gradient(to right, gray,red, black);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 97vh;
    flex-direction: column;
}



form{
    width: 500px;
    border: 2px solid #ccc;
    padding: 30px;
    background: #fff;
    border-radius: 15px;   
}

h2{
    text-align: center;
    margin-bottom: 40px;    
}

input{
    display: block;
    border: 2px solid #ccc;
    width: 95%;
    padding: 10px;
    margin: 10px auto;
    border-radius: 5px;
        } 

button{
    background-color: white;
    padding: 10px 15px;
    color: green;
    border-radius: 5px;
    margin-left: 10px;
    border: 2px solid green;
    cursor: pointer;
}
button:hover{
    background-color: green;
    color: white;
}
.error{
    background: #F2DEDE;
    color: #A94442;
    padding: 10px;
    border-radius: 5px;
    position: relative;
    top:300px;
    z-index: 2;
   /* margin: 20px auto; */
} 
h1 {
    text-align: center;
    color: #fff;
}
        .back {
            background: #555;
            padding: 10px 15px;
             color: #fff;
             border-radius: 5px;
            border: none;
            text-decoration: none;
            margin-right: 1280px;
            position: relative;
            bottom: 100px;
            
        }
    </style>
    </head>
<body>
       <a href="userlogin.php" class="back">BACK</a> 
     <?php if(isset($_GET['error'])){
        $get = $_GET['error'];?>
    <?php echo "<script type='text/javascript'> alert('$get')</script>"; ?>
    <?php   } ?>
    <form action="adminlogin1.php" method="post">
        <h2>ADMIN</h2>
     
        <input type="text" name="user_name" placeholder="user_name" required><br>
        <input type="password" name="password" placeholder="Password" required><br>   
        
        <button type="submit">Login</button>
    </form>        

</body>
</html>