<html>
<head>
   <title>NIE-INFO</title>
    <style>
        body {
            padding: 0;
            margin: 0;
        }
    .co {
            width: 100%;
            height: 300px;
        }
        #logo {
            position: relative;
            bottom: 100px;
            left: 5px;
            border-radius: 10px;
        }
        h1{
            
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
        } 
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
        }
       /* #b,#r {
            margin-left: 30px;
        } */
        
        #n {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        }
        a:hover {
            color: red;
             border-bottom:solid 3px red;
             padding-bottom: 10px;
        } 
        
           a {
            text-decoration: none;
            color: black;
               
        
        }
        li {
            margin-left: 60px;
        } 
        p{
            text-indent: 50px;
            text-align: justify;
            font-family: cursive;
        }
        .p  {
            /* box-shadow: 5px 10px 18px #888888; */
            padding: 30px;
            
        }
           table {
            border-collapse: collapse;
            width: 70%;
            margin-left: 200px;
            margin-top: 50px;
            margin-bottom: 50px;
             font-family: arial, sans-serif;
             
        }
        td, th {
           border: 2px solid black;
           text-align: center;
           padding: 8px;
            font-family: cursive;
        }
        tr:hover {
            background-color: #ddd;
            color: red;
        }
         h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
            
        }
         .ba {
             /*background-image: linear-gradient(to bottom right, red , blue); */
           /* background-image: linear-gradient(to right, rgba(255,0,0,0), rgba(255,0,0,1)); */
             background-image: linear-gradient(to bottom,  lightgray ,yellow);
            margin-top: 40px;

        }
        h2 {
            color: blueviolet;
        }
</style> </head> 
<body>
<div>
<div class="co">
<img  id="im" src="nie1.jpg" alt="nie" width="100%" height="300">
<div><h1>The National Institute of Engineering</h1>
<h3>Mananthavadi Rd, Vidyaranyapura, Mysuru, Karnataka 570008 - 821345670</h3></div></div>
<div>
<ul type='none'>
<li id="n"><a href="nie_info.php">INFO</a></li> 
<li id="b"><a href="nie_branch.php">BRANCH</a></li>
<li id="g"><a href="nie_gallery.php">GALLERY</a></li>
<li id="r"><a href="nie_rating.php">RATING</a></li>
</ul>
</div>
<div class="ba">
<div class="p">
   <p>The National Institute of Engineering (NIE), established in the year 1946, today stands 178th place among top engineering colleges in the country that include IITs and NITs as per National Institution Ranking Framework (NIRF-2019) announced by Ministry of Human Resources Development (MHRD). It is ranked 18 among India’s top Engineering Colleges, as per survey conducted by Times of India (June 2019). NIE is managed by a registered society and nine out of ten current directors are distinguished alumni of the institute.

NIE is a grant-in-aid institution and approved by the All India Council for Technical Education (AICTE), New Delhi. NIE got autonomous status from Visvesvaraya Technological University, Belagavi in 2007.  It has been accredited by NAAC.  Five Undergraduate Programmes - Civil Engineering, Mechanical Engineering, Electronics & Communication Engineering, Electrical & Electronics Engineering and Industrial & Production Engineering and three PG Programmes – Hydraulics, Production Engineering & System Technology and Structural Engineering have been accredited by the National Board of Accreditation, New Delhi, under Tier-I.  It is one of the 14 colleges in Karnataka that has been recognized under the MHRD-World Bank-sponsored Technical Education Quality Improvement Programme (TEQIP) in all the three phases. All the Departments of NIE are recognized as Research Centre under VTU and AICTE for QIP.  Currently, NIE offers 7 UG and 12 PG Programmes.  Faculty has been the main strength of NIE.  They impart their vast knowledge to the students by using conventional methods of teaching-learning process as well as contemporary ones.  </p> 
<div>
    <h2>The National Institute of Engineering Highlights:</h2>
    <table>
    <tr>
    <td>Established</td>
    <td>1946</td></tr>
    <tr>
    <td>Type</td>
    <td>Autonomous</td>
    </tr>
    <tr>
    <td>Approval</td>
    <td>AICTE</td>
    </tr>
   <!-- <tr>
    <td>Affiliation</td>
    <td> SCTIMST , University of Madras</td>
    </tr> -->
    <tr>
    <td>Popular Courses</td>
    <td>BE, M.Tech, MCA</td>
    </tr>
    <tr>
    <td>Official Website</td>
  <td> <a href="http://www.nie.ac.in/" target="_blank">http://www.nie.ac.in/</a> </td>
    </tr>
    </table>
    
    
    </div>
</div>
    </div></div>
</body>
</html>