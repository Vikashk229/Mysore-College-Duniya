<html>
<head>
<title>NIEIT-GALLERY</title>
    <style>
                body {
            padding: 0;
            margin: 0;
        }
       .co {
            width: 100%;
            height: 300px;
        } 
        #logo {
            position: relative;
            bottom: 100px;
            left: 5px;
            border-radius: 10px;
             
        }
      h1{
            
            color: white;
            position: absolute;
            top: 200px;
            left: 30px;
           
        }  
        #im {
            filter: opacity(50%);
            filter: brightness(45%);
        }
        li {
            display: inline;
            margin-left: 60px;
        }
       /* #b,#g {
            margin-left: 30px;
        } */
        #g {
            border-bottom:solid 3px red;
            padding-bottom: 10px;
        
        }
         a:hover {
            color: red;
              border-bottom:solid 3px red;
              padding-bottom: 10px;
        }
           a {
            text-decoration: none;
            color: black;
        
        }
   .photos {
     width:280px;
     height: 200px;
     margin: 10px;
     border-radius:10px;
     margin-top: 30px;
           } 
    .photos:hover {
             box-shadow: 0 20px 20px 0 rgba(0,0,0,0.60), 10px 17px 50px 30px rgba(0,0,0,0.30);
      }
        h2 {
            text-align: center;
            background-color: aqua;
            margin-top: 50px; 
            padding: 10px; 
            border-radius: 30px 0px 30px 0px;
            margin-left: 20px;
            margin-right: 20px;
        }
        .gallary_photos {

          /*  margin-left: 60px; */
        }
          h3 {
           position: absolute;
            top: 250px;
            left: 30px;
            color: whitesmoke;
            
        }
    </style>
    
    </head>
<body>
<div>
 <div class="co">
<img id="im" src="Primary%20NIE.jpg" alt="nie it" width="100%" height="300">
<div><h1>NIE INSTITUTE OF TECHNOLOGY,MYSURU</h1>
<h3>No 50, Koorgalli Village, Hootagalli Industrial Area, next to BEML, Mysuru, Karnataka 570018 - 821234334</h3></div></div>
<div>
<ul type='none'>
<li id="n"><a href="nieit_info.php">INFO</a></li> 
<li id="b"><a href="nieit_branch.php">BRANCH</a></li>
<li id="g"><a href="nieit_gallary.php">GALLERY</a></li>
<li id="r"><a href="nieit_rating.php">RATING</a></li>
</ul>
</div>
</div>
<h2>CAMPUS</h2>
<div class="gallary_photos">
<img src="nieitcampus1.jpg" class="photos">
<img src="nieitcampus2.jpg" class="photos">
<img src="nieitcampus3.jpg" class="photos">
<img src="nieitcampus4.jpg" class="photos">
<img src="nieitcampus5.jpg" class="photos">
<img src="nieitcampus6.jpg" class="photos">
<img src="nieitcampus7.jpg" class="photos">
<img src="nieitcampus8.jpg" class="photos">
<img src="nieitcampus9.jpg" class="photos">
<img src="nieitcampus10.jpg" class="photos">
<img src="nieitcampus11.jpg" class="photos">
</div>
<h2>SPORTS DAY</h2>
<div class="gallary_photos">
<img src="nieitsprots.jpg" class="photos">
<img src="nieitsprots1.jpg" class="photos">
<img src="nieitsprots3.jpg" class="photos">
<img src="nieitsprots4.jpg" class="photos">
</div>
<h2>CLASSROOM</h2>
<div class="gallary_photos">
<img src="nieitclassroom.jpg" class="photos">
<img src="nieitclassroom1.jpg" class="photos">
<img src="nieitclassroom2.jpg" class="photos">
<img src="nieitclassroom3.jpg" class="photos">
<img src="nieitclassroom4.jpg" class="photos">
<img src="nieitclassroom5.jpg" class="photos">
<img src="nieitclassroom6.jpg" class="photos">
</div>
</body>
</html>